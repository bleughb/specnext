.nxc test bundle for Dean, 2026-11-05
=====================================

Hi Dean. This is everything needed to play all 33 published .nxc patches on a
Next: the loader, the Browser line, and each game's patch beside the game file
it needs. Thanks again for merging the NexClash refactor today.

The game files are here for this test only. Please don't pass them on.


1. Set up the card (once)
-------------------------
Tested with NextZXOS v2.09.

Easy way, from a PC with Python 3:

    python3 setup/setup_card.py /path/to/your/sdcard
    (Windows: py setup\setup_card.py E:\ )

It copies the loader (dot/NEXCLASH) and NXCHAND.BAS, and adds one line to the
Browser's settings, keeping a backup of browser.cfg. --dry-run shows what it
would do without changing anything.

By hand: copy sdcard/dot/NEXCLASH to the card's dot folder and
sdcard/nextzxos/NXCHAND.BAS to its nextzxos folder, then add the .nxc line to
nextzxos/browser.cfg (see github.com/jattree/nxc, sdcard/nxc/README.txt).


2. Copy the games
-----------------
Copy the folders in sdcard/nxc to the card, anywhere you like. Each folder has
the .nxc, its .nfo with the details, and the game file it needs. New Zealand
Story has its two tape files (either the .tap or the .tzx with Side B works).


3. Play
-------
In the Browser, open a game's folder and choose its .nxc. The menu shows the
cheats and the options: the clash fix (off gives the original game), Enhanced
colours where a game has them, and game options such as Smooth scrolling (New
Zealand Story), QAOP + Space (Atic Atac, Sabre Wulf) or Original keys (Dynamite
Dan). Number keys change the lines. ENTER plays: "Patching..." flashes while
the game is rebuilt, then it starts. BREAK cancels.


The games (33)
--------------
Atic Atac, Cauldron, Chuckie Egg, Cobra, Commando, Cyclone, Dizzy, Dynamite
Dan, Everyone's a Wally, Herbert's Dummy Run, Ikari Warriors, Incredible
Shrinking Fireman, Jet Pac, Knight Tyme, Lode Runner, Lunar Jetman, Match Day,
Midnight Resistance, The New Zealand Story, Nightshade, Nodes of Yesod,
Pyjamarama, Rainbow Islands, Rambo, Renegade, Sabre Wulf, Smash TV, Solomon's
Key, Spellbound, Starquake, Target: Renegade, Three Weeks in Paradise,
Treasure Island Dizzy.

New since your last bundle:
  Cobra, Herbert's Dummy Run, Nodes of Yesod (128K), Pyjamarama, Sabre Wulf,
  Solomon's Key, Dynamite Dan
  Your games, rebuilt: Cauldron 1.1 (bats keep their own colours, no
  one-frame vanishes, original pace), Lode Runner and Treasure Island Dizzy
  on their 128K files with the AY music, Match Day 2.0 (the trophy screen
  drawn clean; it still plays 2-4% slow, a timing fix is coming)
  Updated: Nightshade (hand-painted Enhanced, original pace), Atic Atac 1.3
  (QAOP + Space), Sabre Wulf 1.1 (QAOP + Space), Dynamite Dan 1.1 (QUIT and
  PAUSE can be redefined)

Every game is checked against its original's pace (within 2%, never faster;
Match Day is the one exception, noted above). Jon has played them all on his
NextTang hardware. Your Next would be the first official board.


Things we'd like you to look at
-------------------------------
- Anything that looks or plays differently from your own builds.
- New Zealand Story needs a core with the tilemap.
- The specnext reference files for the new games are in bleughb/specnext
  PR #64 (no .256 files). Your atic_atac/AticAtac.rzx is the one file we
  don't have, if you can add it.

Thanks for the engines. None of this would exist without them.
Jon
