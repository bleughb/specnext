import hashlib,json,shutil
from pathlib import Path
root=Path.cwd();build=root.parent/'specnext/reference/inferno/build'
def md5(p):return hashlib.md5(p.read_bytes()).hexdigest()
p=root/'docs/records/inferno.json';r=json.loads(p.read_text())
r['status'].update(engine_col='inferno pinned B components (inferno.md)',build='immutable source / B / transfer components',next='affordable exact validation, safe prewarm and complete frame integration')
r['excluded']='Stage 2 incomplete: standalone assembled pinned live-source/exact-validation, B fill and protected transfer components; host cache selection only. Runtime cache/scheduler/allocator/display/continuous frontend remain open. Total timing FAIL; no sprite NEX, hardware proof or stamp.'
summary=json.loads((build/'actor_job_summary.json').read_text())
sources=['nexclash/inferno.py','asm/inferno_hooks.asm','docs/profiles/inferno.json']
artifacts=['actor_jobs.md']+[p.name for p in build.glob('actor_job_*') if p.is_file()]+['actor_job_quick/'+p.name for p in (build/'actor_job_quick').glob('*.json')]
r['actor_jobs']={
 'scope':summary['scope'],
 'sources':{n:md5(root/n) for n in sources},
 'artifacts':{n:md5(build/n) for n in sorted(artifacts)},
 'quick_counts':summary['counts'],
 'units':json.loads((build/'actor_job_checks.json').read_text()),
 'timing_gate':{'target_total_added_ms':10,'status':'FAIL','cold_snapshot_inclusive_max_ms':summary['counts']['max capture scenery snapshot cold colour and B fill equivalent T']/3500,'source_work_update_max_ms':summary['counts']['max live job tick equivalent T']/3500,'excluded':'cache lookup/allocation, uploads, queue and external snapshot/fill wrappers','hardware_proof':False},
 'memory':'page 78 source worker; page 122 one pinned 8 KiB stream; page 75 P_RAW 1EC0..1EC8/P_SOURCE 1EDB; all prior reservations retained',
 'dma_evaluation':'27 prepared single-span proxies, not live-source DMA. Single spans <64 bytes bypass capability/setup to CPU; larger rectangles prefer gated DDMA; protected pair uploads retain DMA and CPU fallback. No-blitter policy retained. Physical stalls unknown.',
 'required_checks':{'six_quick_correctness':'PASS: 12000 frames, 128 captures / 13066 exact validations / 128 B fills','assembly':'PASS: 17 blocks / 100 symbols','shared_tools':'PASS; optional reference-dependent cases skipped as logged','canary':'PASS: Chuckie Egg unchanged','level4_shop':'PASS: sampled original return only','doccheck':'pending','total_timing':'FAIL','hardware':'UNPROVED'},
 'recipes':['python tools/asm2profile.py --check inferno','python -m nexclash.inferno --actor-job-checks','python -m nexclash.inferno --actor-pack-checks','python -m nexclash.inferno --actor-fill-checks','python -m nexclash.inferno --actor-blit-checks','python -m nexclash.inferno --actor-pack-all ../specnext/reference/inferno --quick 2000 --out work/actor_job_quick --json work/actor_job_summary.json','python -m nexclash.inferno --modal-checks ../specnext/reference/inferno/build/modal4_entry.json'],
 'replay_dependencies':{n:md5(root/n) for n in ['nexclash/rzx.py','nexclash/simpool.py','nexclash/z80n.py','nexclash/dizzy6.py','nexclash/build.py']},
 'shared_sources':{n:md5(root/n) for n in r['actor_b']['shared_sources']}}
p.write_text(json.dumps(r,indent=1)+'\n')
