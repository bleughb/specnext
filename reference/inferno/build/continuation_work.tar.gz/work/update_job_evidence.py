import hashlib,json,shutil
from pathlib import Path
root=Path.cwd(); build=root.parent/'specnext/reference/inferno/build'
files=['actor_job_checks.json','actor_job_pack_checks.json','actor_job_fill_checks.json','actor_job_blit_checks.json','actor_job_modal_checks.json','actor_job_summary.json','actor_job_assembly.txt','actor_job_tools.txt','actor_job_canary.txt']
for name in files: shutil.copy2(root/'work'/name,build/name)
shutil.copytree(root/'work/actor_job_quick',build/'actor_job_quick',dirs_exist_ok=True)
rows=[]
for level in range(1,7):
 d=json.loads((build/f'actor_job_quick/actor_pack{level}.json').read_text());t=d['timing_gate'];c=d['counts']
 rows.append(f"| {level} | {c['assembled immutable live job captures']} / {c['assembled exact live job validations']} | {t['cold_with_snapshot_validation_max_ms']:.3f} | {t['live_snapshot_validation_tick_max_ms']:.3f} |")
p=build/'actor_jobs.md';s=p.read_text().replace('The six-level canonical replay totals and per-level costs are recorded below after validation.', '''Six original 2,000-frame correctness replays PASS: 128 assembled live captures, 13,066 assembled
exact validations, 1,319 pinned-source tile conversions and 128 complete B fills / 108,288 actor
pixels, retaining 16,903 capture comparisons and 1,850 post-copy hooks / 68,198,400 scenery pixels.
The host cache selects candidate entries; these are component executions, not installed runtime
cache hits. Original RAM/register/IRQ and targeted level-4 shop checks remain passing.

| Level | Captures / validations | Cold capture/scenery/snapshot/colour/B, ms | Snapshot/validation worst update alone, ms |
|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

All six total timing gates FAIL. The cold totals exclude cache lookup/allocation, uploads, queue
and external wrappers. Snapshot/validation maxima are independent updates, so do not add them to
the cold-column maximum again. Largest sampled source is 1121 bytes; one sampled source call
costs up to 9.492 ms. Existing capture/scenery can take 8.715 ms and queue about 0.55 ms, leaving
about 0.735 ms before any actor work; the measured validator cannot fit that conservative sum.
Pinned colour decoding is slightly cheaper than original-source decoding, hence the older cold
subtotal changes slightly even before adding snapshot costs. This does not fix cold B latency.

Bundled assembly (17 blocks / 100 exported symbols), shared tools, Chuckie Egg canary and
sampled level-4 shop units PASS. Software checks are separate from absent hardware proof.''');p.write_text(s)
p=build/'README.md';s=p.read_text();s=s.replace('Latest checkpoint: [actor_b_compiler.md]', '''Latest checkpoint: [actor_jobs.md](actor_jobs.md) adds assembled immutable live-source snapshots,
exact byte/phase/paint validation and a pinned-source colour consumer. Six quick correctness runs
pass (128 captures / 13,066 validations). Snapshot-inclusive cold timing still FAILS: 899.45 ms L1,
84.29 ms L6 against 10 ms total, excluding lookup/allocation/uploads/queue/wrappers. Tiny prepared
spans use CPU after DMA/DDMA evaluation. No runtime cache/scheduler or sprite NEX is installed.

Previous checkpoint: [actor_b_compiler.md]''',1);p.write_text(s)
p=build/'CONTINUE.md';s=p.read_text();s=s.replace('Latest implementation/evidence: [actor_b_compiler.md](actor_b_compiler.md), on these same branches.', '''Latest implementation/evidence: [actor_jobs.md](actor_jobs.md), on these same branches.
The immutable source worker is page 78 / pinned stream page 122; page 75 accepts copied raw tiles.
Read actor-job unit/replay evidence before the historical B checkpoint below. All six quick
correctness replays PASS: 128 captures / 13,066 exact validations. Snapshot-inclusive cold totals
FAIL: L1 899.447 ms / L6 84.289 ms, target 10 ms TOTAL; lookup/allocation/uploads/queue/wrappers
excluded. Per-update source work alone reaches 24.650 ms. Do not install the synchronous walker
as a long DI hook. Next: reduce exact-validation cost, prove source-lifetime deduplication if used,
then assembled stream dispatch, runtime cache/allocator and safe early hook/scheduling. No sprite
NEX. Preserve current/pending ownership, caller-speed/R and ORIGINAL-pace obligations. DMA/DDMA
span probes retain gated larger copies/uploads and route single spans <64 bytes directly to CPU.
This preserves original geometry/bitmap/attribute bytes; host cache selection is not runtime code.

Historical B implementation/evidence: [actor_b_compiler.md](actor_b_compiler.md).''',1);p.write_text(s)
p=root/'games/inferno.md';s=p.read_text();a=s.index('Stage: 2 (continued)');b=s.index('\n## Inputs and facts',a)
s=s[:a]+'''Stage: 2 (continued)    State: immutable source components pass; total timing FAIL
Inputs: specnext/reference/inferno/    Branch: codex/inferno (build/CONTINUE.md)
Start: refresh main; read build/actor_jobs.md, actor_b_compiler.md, actor_packing.md and frame_pipeline.md.
Read: inferno.py run_actor_job/actor_job_checks/model_verify/run_actor_pack and matching ASM.
Next: make exact live validation affordable; prove any source-lifetime deduplication. Then assembled
  stream dispatch, runtime content cache/allocator and safe early hook/preparation schedule.
  Page 78 pins ordered original run-list/bitmap/attribute bytes in page 122. Page 75 accepts copied
  raw tiles. Six quick correctness runs PASS: 128 captures / 13,066 exact validations / 128 B fills.
  Host selects cache entries; no installed cache/scheduler. Never accept pointer/hash-only validity.
  Source work alone reaches 24.650 ms/update; cold snapshot-inclusive L1 899.447 / L6 84.289 ms,
  target 10 ms TOTAL, excluding lookup/allocation/uploads/queue/wrappers. Long DI walker is not safe.
  Page 77 prefers gated DDMA / DMA with no-blitter/CPU fallback; spans <64 bytes now bypass setup.
  Physical stalls/ownership/IRQ proof remains open. Keep current AND pending pattern allocations.
Workflow: Inferno6.rzx --quick 2000; six original level replays at milestones; targeted level-4 shop.
Open: pattern layout/protected uploads/complete-frame switch, FLASH/modal/frontend/ROM lifetime,
  recolour/sheets and hardware/whole-tick timing. Apply caller-speed/R and ORIGINAL-pace before build.
Next prompt: "Continue Inferno stage 2 from build/actor_jobs.md and CONTINUE.md. Preserve pinned exact
live data, original RAM/registers/priority and approved B visuals. Solve validation cost and safe live
preparation, retain profitable gated blitter/DMA paths; keep sprites disabled until complete."
''' +s[b:]
pos=s.index('## Whole-image B / prepared transfer checkpoint')
s=s[:pos]+'''## Immutable job checkpoint (2026-11-07; build/actor_jobs.md)
- Page 78 / stream page 122 captures ordered original geometry, IDs and bitmap/attribute bytes.
  Exact byte/length/phase/paint comparison preserves pinned data; malformed/overflow jobs never publish.
- Page 75 pinned input forbids original graphics reads. Host dispatch/cache selection remain models.
  Six quick replays: 128 captures / 13,066 validations / 128 complete B fills pass; no display enabled.
- DMA/DDMA prepared-span evaluation adds 27 cases. Single spans <64 bytes bypass setup with CPU;
  larger copies/uploads keep gated shared backend, no-blitter and CPU fallback. Stalls remain unknown.
- Snapshot-inclusive cold totals FAIL: L1 899.447 / L6 84.289 ms, target 10 ms total, excluding
  lookup/allocation/uploads/queue/wrappers. Source work alone peaks at 24.650 ms/update. No safe hook.

''' +s[pos:]
s=s.replace('## Lessons\n','''## Lessons
- [local: Inferno immutable sources] Pin complete ordered original bytes before resumable work;
  exact validation can itself exceed the budget. DI component correctness does not prove safe entry.
''',1)
s=s.replace('## Friction\n','''## Friction
- reuse: [local: Inferno source jobs] Restored archived work only into absent work/, merged both mains
  preserving Inferno status/process guidance; measured shared adapter spans instead of new DMA code.
''',1)
s=s.replace('## Stage log\n','''## Stage log
- 2026-11-07: stage 2 continued, mains refreshed, scratch preserved. Assembled pinned source/exact
  validation and raw-tile consumer; six quick correctness, shop, assembly/tools/canary PASS. DMA span
  evaluation removes tiny-copy setup. Total timing FAIL (899.447 / 84.289 ms L1/L6); no sprite NEX.
''',1)
p.write_text(s)
