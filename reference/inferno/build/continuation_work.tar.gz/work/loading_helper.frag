def prepare_loading_cache(ram):
    """Frozen-live-RAM loading experiment; host dispatch/allocation, assembled workers.

    No RZX-derived catalogue. Every possible C100 index is scanned at this instant.
    A real wrapper/safe initialization boundary is still required before installation.
    """
    cache,jobs,contents = {},{},bytearray(80*8192)
    used,cost,tiles_count,pixels_count = 0,0,0,0
    rejected = Counter()
    for image in range(256):
        try:
            actor = actor_descriptor(ram,image)
            key = tuple((x,y,t,raw_tile(ram,t)) for x,y,t in actor['tiles'])
            if not key or key in cache:
                continue
            left,top,width,height,pixels = solid_image(tuple((x,y,raw) for x,y,t,raw in key))
            if width > 1024:
                raise ValueError('canvas stride')
        except (ValueError,IndexError):
            rejected['malformed/unsupported live candidate'] += 1
            continue
        job = run_actor_job(ram,image=image)
        cost += job['equivalent_T']
        if not job['done'] or job['error']:
            rejected['snapshot capacity/record refusal'] += 1
            continue
        if actor_job_tiles(job['stream']) != key:
            raise AssertionError('loading snapshot differs from original')
        size = width*height//2
        needed = len(job['stream'])+size
        if used+needed > len(contents):
            rejected['expanded cache capacity'] += 1
            continue
        canvas = bytes(32768)
        for x,y,t,raw in actor_job_tiles(job['stream']):
            dest = ((y*8-top)*width+x*8-left)//2
            result = run_actor_pack(ram,t,dest,width//2,raw=raw,canvas=canvas)
            if not result['valid']:
                raise AssertionError('loading tile rejected')
            canvas = result['canvas']
            cost += result['equivalent_T']
            tiles_count += 1
        filled = run_actor_fill(canvas,width//2,size)
        cost += filled['equivalent_T']
        actual = bytes(c for b in filled['canvas'][:size] for c in (b >> 4,b & 15))
        if actual != pixels:
            raise AssertionError('loading B pixels differ')
        payload = job['stream']+filled['canvas'][:size]
        contents[used:used+needed] = payload
        # Host packing of complete owned images in proposed pages 136..215.
        # No display/pattern allocation or runtime readiness flag is published.
        cache[key] = 0
        jobs[key] = {p:job['pages'][p] for p in (78,122)}
        used += needed
        pixels_count += len(pixels)
    return cache,jobs,{'prepared_images':len(cache),'packed_source_and_canvas_bytes':used,
                      'cache_capacity_bytes':len(contents),'assembled_tiles':tiles_count,
                      'assembled_B_pixels':pixels_count,'preparation_cpu_ms':cost/3500,
                      'rejected':dict(rejected),
                      'scope':'frozen live-table loading experiment with assembled snapshot/colour/B; host scan/dispatch/allocation; excludes scan, zeroing, cache-store copies, wrappers and hardware stalls'}


