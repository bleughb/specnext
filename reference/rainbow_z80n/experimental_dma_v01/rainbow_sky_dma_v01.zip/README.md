# Rainbow Islands sky DMA — experimental v0.1

These are complete Rainbow Islands game builds, based on the existing sky rework.
Source: https://github.com/bleughb/nexclash/pull/95
Reference manifests: https://github.com/bleughb/specnext/pull/67

## Choose a file

- `rainbow_sky_dma_v01_blitter.nex`: default; prefers the new general 2D blitter on core 3.03.00+.
  Older supported cores use ordinary DMA. Unexpected hardware IM2 uses CPU fallback.
- `rainbow_sky_dma_v01_no_blitter.nex`: ordinary DMA with CPU fallback; never uses extended commands.
- `rainbow_sky_dma_v01_cpu_only.nex`: CPU LDIR baseline for the same sky game.
- `rainbow_sky_dma_v01_blitter_diag.nex`: blitter preference plus the existing diagnostic border.

## Install and compare

Copy the NEX files to a separate folder on your Next's SD card. Launch with NextZXOS .nexload.
The loading screen exits after its timeout or a fresh key press. Use the same scene and inputs
when comparing the three policies. Keep the pinned build on the card for comparison.
The experiment retains the sky rework, class colours (no thrown-rainbow outline), graphics cache,
AY queue and three-interrupt game pace. Pinned releases have not been replaced.

Verify files using `sha256sum -c SHA256SUMS.txt` (or an equivalent checksum utility).
`manifest.json` contains full SHA-256 and MD5 hashes. All NEX files are 213,504 bytes.

## Software scope

Software results: complete rainbow.rzx, 7,178 observed replay frames, 2,212 commits; rainbownew.rzx sampled at 2,000 requested frames (2,008 observed), 489 commits; no-blitter, CPU-only, old-core and hardware-IM2 routes sampled at 200 requested frames each on an active island-1 boss segment. Twelve LeeBee gameplay cuts sampled (five boss cuts at 200 and seven round-start cuts at 1,200 requested frames), plus a 200-frame ending sample with no commit hook reached. All reported comparisons pass. The full recording still has 60 modeled frames over 20 ms, max 25.666 ms before wait states; recovery comparisons pass. The latter ending sample is not DMA gameplay proof. The legacy game unit suite uses six captured dispatch states from a 1,200-frame capture, plus its object/AY/raster cases and negative controls. Hardware is untested.

See `validation.json` for exact recording identities, coverage, counters, failures and timing.
The verifier checks registers, mapped memory, figure pixels, tilemap content, sky palette,
commit state and queued AY output. DMA callbacks perform the real mapped transfer; port counts
alone are not used as proof. Autosave snapshots are removed before replay.
Seven data-free test groups cover the assembled game's commit, 24 policy/core/IM2 combinations,
source/destination/gap preservation, elapsed stalls and wrap recovery, the loading entry bank,
and six broken controls (including a shifted-palette operand). Assembly profiles, shared tools, canary and doccheck are separate gates.
Sampled LeeBee checks do not prove full islands or an entire playthrough. This is not a new
full-game verification stamp. Hardware has not been tested.

## Timing assumptions

The software model injects transfer time at an assumed 4 MB/s and records it separately from CPU
instruction cost. Complete hooks include setup, mapping, cache effects and deferred commits.
`hook_profile.csv` labels raw T separately; clock-adjusted fields in matched active-boss policy
profiles account for NextReg $07 speed changes. Empty clock-adjusted fields denote legacy raw profiles.
Synthetic whole tcommit at that assumption: blitter ~0.41 ms, ordinary DMA ~0.73 ms, CPU ~1.05 ms.
Sensitivity cases use 8, 4, 1 and 0.5 MB/s. These are assumptions, not measured Next rates.
The immediate-commit map allowance is 64 raster lines; the existing interrupt-deferred path and
overrun recovery remain. Measure the real worst case before treating that budget as established.

## Remaining Next checks

Record board issue, exact core, file hash, policy and actual selected backend.

1. Boot, loading screen, menus, start, death, continue, round/island/boss transitions and ending.
2. Sky on islands 1 and 4–7; unchanged sky on islands 2–3; figures, objects, colours, depth,
   thrown rainbows, scrolling and busy scenes. Check tearing, stale tiles and missing figures.
3. Whole-hook and whole-commit worst times, including setup, mapping, stalls and cache misses;
   deferred commits must finish the top rows before the beam. Check raster overruns/recovery.
4. Steady music and sound, ULA interrupt delivery while DI is active, and no DMA deadlock.
5. Old-core fallback, explicit no-blitter on a DDMA core, and the CPU baseline. Compare quiet
   and busy gameplay pace and worst-frame hitches. Capture video and identify the scene on faults.

## Rebuild

Checkout the source PR. Install requirements.txt. Keep specnext beside nexclash, with the recorded
rainbow.z80 and rainbow_z80n_loading.scr present. From nexclash:

```
python -m nexclash.rainbow_dma build --snapshot ../specnext/reference/rainbow_islands/rainbow.z80 --out work/rainbow-dma
python -m nexclash.rainbow_dma build --snapshot ../specnext/reference/rainbow_islands/rainbow.z80 --out work/rainbow-dma --no-blitter
python -m nexclash.rainbow_dma build --snapshot ../specnext/reference/rainbow_islands/rainbow.z80 --out work/rainbow-dma --cpu-only
```

Add `--diagnostic` for the border build. These flags build the game, not the synthetic DMA harness.
Game data and binaries are absent from the public toolkit PR. Because GitHub currently marks
specnext public too, its new PR contains only the manifests and validation handoff.
